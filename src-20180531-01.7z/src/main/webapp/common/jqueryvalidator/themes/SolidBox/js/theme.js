var onShowHtml = "<div class='$class$'>$data$</div>";
var onFocusHtml = "<div class='$class$'>$data$</div>";
var onErrorHtml = "<div class='$class$'>$data$</div>";
var onCorrectHtml = "<div class='$class$'>$data$</div>";
var onShowClass = "input_show";
var onFocusClass = "input_focus";
var onErrorClass = "input_error";
var onCorrectClass = "input_correct";