package dao;

import entity.ProjectCase;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface ProjectCaseDao extends BaseDao<ProjectCase>{
    public ArrayList<ProjectCase> findByProjectId(int id);
    public ArrayList<ProjectCase> findByCaseId(int id);
}
