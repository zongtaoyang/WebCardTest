package dao;

import entity.Project;
import org.springframework.stereotype.Repository;

@Repository
public interface ProjectDao extends BaseDao<Project>{

}
