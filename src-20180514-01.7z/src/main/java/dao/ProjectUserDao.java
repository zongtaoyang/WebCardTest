package dao;

import entity.ProjectUser;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;

@Repository
public interface ProjectUserDao extends BaseDao<ProjectUser>{
    public ArrayList<ProjectUser> findByProjectId(int id);
    public ArrayList<ProjectUser> findByUserId(int id);
}
