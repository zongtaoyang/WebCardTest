package dao;
import java.util.ArrayList;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import entity.Execute;

@Repository
public interface ExecuteDao extends BaseDao<Execute>{

}
