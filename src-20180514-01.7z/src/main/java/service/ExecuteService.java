package service;

import java.util.ArrayList;

import entity.Execute;

public interface ExecuteService extends BaseService<Execute>{
}
