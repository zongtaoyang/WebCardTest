package service;

import dto.ProjectStatistic;
import entity.Project;

import java.util.ArrayList;

public interface ProjectService extends BaseService<ProjectStatistic>{
    public ArrayList<ProjectStatistic> allWithProgress();
    public Project findByIntIdWithProgress();
}
