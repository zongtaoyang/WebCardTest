package service.impl;

import dao.*;
import dto.ProjectStatistic;
import entity.Project;
import entity.ProjectCase;
import entity.ProjectUser;
import org.springframework.stereotype.Service;
import service.ProjectService;

import javax.annotation.Resource;
import java.util.ArrayList;

@Service
public class ProjectServiceImpl extends BaseServiceImpl<ProjectStatistic> implements ProjectService {

    private ProjectDao projectDao;
    private ExecuteDao executeDao;//用于查询执行记录，并计算project的进度
    private ProjectCaseDao projectCaseDao;//用于查询某project的case列表
    private ProjectUserDao projectUserDao;//用于车讯某project的user列表
    private UserDao userDao;//用于查询某个user id对应的name
    private CaseDao caseDao;//用于查询某个case id对应的name

    @Resource
    public void setProjectDao(ProjectDao projectDao) {
        this.projectDao = projectDao;
    }

    @Resource
    public void setExecuteDao(ExecuteDao executeDao) {
        this.executeDao = executeDao;
    }

    @Resource
    public void setProjectCaseDao(ProjectCaseDao projectCaseDao) {
        this.projectCaseDao = projectCaseDao;
    }

    @Resource
    public void setProjectUserDao(ProjectUserDao projectUserDao) {
        this.projectUserDao = projectUserDao;
    }

    @Resource
    public void setUserDao(UserDao userDao) {
        this.userDao = userDao;
    }

    @Resource
    public void setCaseDao(CaseDao caseDao) {
        this.caseDao = caseDao;
    }

    @Override
    public ArrayList<ProjectStatistic> allWithProgress() {
        ArrayList<ProjectStatistic> statisticsArray = new ArrayList<ProjectStatistic>();
        ArrayList<Project> arraylist = projectDao.all();
        System.out.println("Project arraylist->" + arraylist);
        for (int i = 0; i < arraylist.size(); i++) {
            Project project = arraylist.get(i);

            //根据project id 获取user列表
            ArrayList<ProjectUser> projectUserArrayList = projectUserDao.findByProjectId(project.getProject_id());
            String projectUserListString = "";
            for (int j = 0; j < projectUserArrayList.size(); j++) {
                if (null != userDao.findByIntId(projectUserArrayList.get(j).getUser_id())){
                    projectUserListString += userDao.findByIntId(projectUserArrayList.get(j).getUser_id()).getUsername() + "|";
                }

            }

            //根据project id 获取case列表
            ArrayList<ProjectCase> projectCaseArrayList = projectCaseDao.findByProjectId(project.getProject_id());
            String projectCaseListString = "";
            for (int k = 0; k < projectCaseArrayList.size(); k++) {
                if(null!=caseDao.findByIntId(projectCaseArrayList.get(k).getCase_id())){
                    projectCaseListString += caseDao.findByIntId(projectCaseArrayList.get(k).getCase_id()).getName() + "|";
                }

            }

            ProjectStatistic projectStatistic = new ProjectStatistic();
            projectStatistic.setProject_id(project.getProject_id());
            projectStatistic.setProject_name(project.getProject_name());
            projectStatistic.setProject_use(project.getProject_use());
            projectStatistic.setCase_list(projectCaseListString);
            projectStatistic.setUser_list(projectUserListString);
            projectStatistic.setCreate_time(project.getCreate_time());
            projectStatistic.setUpdate_time(project.getUpdate_time());
            projectStatistic.setTest_progress(0);//TODO
            statisticsArray.add(projectStatistic);
        }

        return statisticsArray;
    }

    @Override
    public Project findByIntIdWithProgress() {
        Project project = new Project();
        return project;
    }
}
