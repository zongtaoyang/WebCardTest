package service;

import java.util.ArrayList;

import entity.Case;

public interface CaseService extends BaseService<Case>{
}
