package service;

import java.util.ArrayList;

import entity.CGroup;

public interface GroupService extends BaseService<CGroup>{
}
