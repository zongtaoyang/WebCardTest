package service;

import java.util.ArrayList;

import entity.History;

public interface HistoryService extends BaseService<History>{
}
