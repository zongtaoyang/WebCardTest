package controller;

import dto.ProjectStatistic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import service.ProjectService;

import javax.servlet.http.HttpServletRequest;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("WebCardTest/project")
public class ProjectController {
    private final String TAG = "ProjectController->";

    @Autowired
    private ProjectService projectService;

    /**
     * 跳转到项目管理页面
     * @return
     * @throws Exception
     */
    @RequestMapping("/manageproject")
    public ModelAndView manageproject()throws Exception{
        ModelAndView mv = new ModelAndView("WebCardTest/project/manageproject");
        return mv;
    }

    /**
     * 跳转到新增项目页面
     * @return
     * @throws Exception
     */
    @RequestMapping("/toaddproject")
    public ModelAndView toaddproject()throws Exception{
        ModelAndView view = new ModelAndView("WebCardTest/project/addproject");
        return view;
    }

    /**
     * 跳转到用户修改页面
     * @return
     * @throws Exception
     */
    @RequestMapping("/toeditproject")
    public ModelAndView toeditproject(int id)throws Exception{
        ModelAndView view = new ModelAndView("WebCardTest/project/editproject");
        try {
            ProjectStatistic project = projectService.findByIntId(id);
            view.addObject("project", project);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return view;
    }

    @RequestMapping(value = "/find", method = RequestMethod.GET)
    @ResponseBody
    private List<ProjectStatistic> find(HttpServletRequest request) throws IllegalArgumentException, IllegalAccessException {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("project_id", request.getParameter("project_id"));
        map.put("begin_time", request.getParameter("begin_time"));
        map.put("end_time", request.getParameter("end_time"));
        List<ProjectStatistic> result = projectService.find(map);
        String page_size = request.getParameter("page_size");
        String page_num = request.getParameter("page_num");
        if (page_size != null && page_size != "") {
            if (page_num != null && page_num != "") {
                int page_size_int = Integer.valueOf(page_size);
                int page_num_int = Integer.valueOf(page_num);
                result = result.subList(page_size_int * page_num_int, page_size_int * (page_num_int + 1));
            }
        }
        //map.put相当于request.setAttribute方法
        return result;
    }

    @RequestMapping(value = "/list")
    @ResponseBody
    private List<ProjectStatistic> list(HttpServletRequest request) throws IllegalArgumentException, IllegalAccessException {
        System.out.println(TAG + "list...");
        Map<String, Object> result = new HashMap<String, Object>();
        List<ProjectStatistic> array = projectService.allWithProgress();
        System.out.println("arrar->" + array);
        result.put("data", array);
        result.put("stat_code", 0);
        result.put("info", "success");
        result.put("total", array.size());
        System.out.println(TAG + "list array= " + array);
        return array;
    }

    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    @ResponseBody
    private Map<String, Object> edit(HttpServletRequest request) throws IllegalArgumentException, IllegalAccessException {
        Map<String, Object> result = new HashMap<String, Object>();
        try {
            request.setCharacterEncoding("UTF-8");
        } catch (UnsupportedEncodingException e) {

        }
        ProjectStatistic projectStatistic = new ProjectStatistic();
        String id = request.getParameter("project_id");
        String name = "";
        String use = "";
        String user_list = "";
        String case_list = "";
        try {
            name = new String(request.getParameter("project_name").getBytes("iso-8859-1"), "UTF-8");
            use = new String(request.getParameter("project_use").getBytes("iso-8859-1"), "UTF-8");
            user_list = new String(request.getParameter("user_list").getBytes("iso-8859-1"), "UTF-8");
            case_list = new String(request.getParameter("case_list").getBytes("iso-8859-1"), "UTF-8");
        } catch (UnsupportedEncodingException e) {

        }
        System.out.println("project_name" + name + "|project_use=" + use + "|user_list=" + user_list + "|case_list=" + case_list);
        projectStatistic.setProject_name(name);
        projectStatistic.setProject_use(use);
        projectStatistic.setUser_list(user_list);
        projectStatistic.setCase_list(case_list);
        result.put("info", "success");
        result.put("stat_code", 0);
        if (id == "" || id == null) {
            if (projectService.insert(projectStatistic) == 0) {
                result.put("info", "id_error");
                result.put("stat_code", 1);
            }
        } else {
            projectStatistic.setProject_id(Integer.valueOf(id));
            if (projectService.update(projectStatistic) == 0) {
                result.put("info", "id_error");
                result.put("stat_code", 1);
            }
        }
        result.put("data", null);
        result.put("total", 1);
        return result;
    }

    @RequestMapping(value = "/remove", method = RequestMethod.GET)
    @ResponseBody
    private Map<String, Object> remove(int id) throws IllegalArgumentException, IllegalAccessException {
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("info", "success");
        result.put("stat_code", 0);
        if (projectService.delete(id) == 0) {
            result.put("info", "id_error");
            result.put("stat_code", 1);
        }
        result.put("data", null);
        result.put("total", 1);
        return result;
    }
}
