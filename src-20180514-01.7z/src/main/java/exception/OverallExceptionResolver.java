package exception;

public class OverallExceptionResolver {

}
