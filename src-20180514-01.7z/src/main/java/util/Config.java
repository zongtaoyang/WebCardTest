package util;

public class Config {
	public static final String FilePath = "D:/Workspaces/testcase";
}
