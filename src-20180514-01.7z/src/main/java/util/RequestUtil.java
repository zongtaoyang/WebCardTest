package util;

public class RequestUtil {
	public static void saveRequest(){
		
	}
}
